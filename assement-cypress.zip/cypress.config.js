const { defineConfig } = require("cypress");

module.exports = defineConfig({
  chromeWebSecurity: false,
  reporter: "cypress-multi-reporters",
  defaultCommandTimeout: 60000,
  "fixturesFolder": "cypress/fixtures",
  //reporter: 'cypress-mochawesome-reporter', //https://www.browserstack.com/guide/cypress-html-reporter
  video: false,
  reporterOptions: {
      "reporterEnabled": "cypress-mochawesome-reporter, mochawesome",
      "cypressMochawesomeReporterReporterOptions": {
        "embeddedScreenshots": true,
        "charts": true,  
        "reportPageTitle": "Cypress Fluid Report",
        "inlineAssets": true,
        "reportFilename": "cypressE2EReport",
      },
      "mochawesomeOptions":{
        reportDir: 'cypress/results',
        overwrite: false,
        html: false,
        json: true
      }
  },
  e2e: {
    testIsolation: true // or false, depending on your needs
  },
  typescript : './tsconfig.json'
  
});